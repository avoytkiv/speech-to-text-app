# BaseModelFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supports_adaptations_with** | [**list[DatasetKind]**](DatasetKind.md) | Supported dataset kinds to adapt the model. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


