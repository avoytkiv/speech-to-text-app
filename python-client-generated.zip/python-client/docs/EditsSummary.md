# EditsSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_edits** | **int** | The optional number of edits for a given type of error of the recognized transcription in comparison with the human transcription. | [optional] 
**percentage_of_all_edits** | **float** | The optional percentage of edits for a given type of error of the recognized transcription in comparison with the human transcription. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


