# OperationResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **str** | The link to the result of the operation. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


