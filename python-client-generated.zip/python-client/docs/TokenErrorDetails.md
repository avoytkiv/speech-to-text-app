# TokenErrorDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**punctuation** | [**EditsSummary**](EditsSummary.md) |  | [optional] 
**capitalization** | [**EditsSummary**](EditsSummary.md) |  | [optional] 
**inverse_text_normalization** | [**EditsSummary**](EditsSummary.md) |  | [optional] 
**lexical** | [**EditsSummary**](EditsSummary.md) |  | [optional] 
**others** | [**EditsSummary**](EditsSummary.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


